# Privacy and redaction rules

This skill is intended for public reuse. Never embed a real user's hardware inventory or raw system logs in examples, reports, screenshots, or files intended for the internet.

## Replace or remove

| Sensitive field | Public form |
|---|---|
| Username | `<USER>` |
| Hostname | `<HOST>` |
| Computer model | `<SYSTEM_MODEL>` or omit |
| CPU/GPU model | `<CPU_MODEL>` / `<GPU_MODEL>` or omit |
| SSD model | `<SOURCE_MODEL>` / `<DEST_MODEL>` |
| SSD serial | `<SOURCE_SERIAL>` / `<DEST_SERIAL>` |
| Device namespace | `<SOURCE_NAMESPACE>` / `<DEST_NAMESPACE>` |
| Disk path | `<SOURCE_DISK>` / `<DEST_DISK>` |
| Filesystem UUID | `<SOURCE_FS_UUID>` / `<DEST_FS_UUID>` |
| PARTUUID | `<SOURCE_PARTUUID>` / `<DEST_PARTUUID>` |
| GPT disk GUID | `<DISK_GUID>` |
| UEFI Boot#### | `<BOOT_ENTRY_ID>` |
| BCD object GUID | `<BCD_GUID>` |
| MAC address | `<MAC_ADDRESS>` |
| IP address | `<IP_ADDRESS>` |
| Wi-Fi SSID | `<WIFI_SSID>` |
| Domain | `<DOMAIN>` |

Use consistent placeholders within one document so readers can follow relationships. Do not preserve real values by partially masking them (for example, do not expose the final serial digits).

## Secrets: never include, even masked casually

Do not include BitLocker recovery keys, Windows product keys, passwords, private SSH keys, access tokens, cloud credentials, recovery codes, or private certificates. Do not ask the user to paste them into chat.

## Screenshots and metadata

Text replacement does not sanitize screenshots. Inspect every image, terminal title bar, shell prompt, file path, browser tab, QR code, barcode, EXIF metadata and document property. Remove comments, tracked changes, author names and embedded attachments before publication.

## Safe sharing workflow

1. Work from a copy, not the private original.
2. Replace identifiers in text and tables.
3. Inspect screenshots manually; crop or redact irreversibly where needed.
4. Remove document metadata and hidden content.
5. Search the final package for known private values.
6. List all files in the ZIP and inspect archive contents before uploading.
