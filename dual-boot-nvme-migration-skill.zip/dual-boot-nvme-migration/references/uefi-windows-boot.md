# UEFI, Fedora GRUB, and Windows boot configuration

## 1. UEFI prerequisites

Confirm the installed operating systems use UEFI boot and the disks use GPT. Do not apply this procedure unchanged to legacy BIOS/MBR systems.

An EFI System Partition is normally FAT32 and marked as an ESP in GPT. Verify the partition type, filesystem, size, and physical parent disk. Do not identify an ESP only by its label.

## 2. ESP handling

The ESP may contain separate directories for Microsoft, Fedora, and OEM bootloaders. Never replace the entire destination ESP with the source ESP without a deliberate merge plan and backup.

If transferring Fedora boot files, copy only the Fedora directory after confirming that its content is suitable. Preserve or create the Microsoft directory independently. Confirm that Fedora's EFI-side GRUB stub references the destination `/boot` filesystem.

## 3. Windows BCDBoot

Run from an elevated Windows Command Prompt or Windows Recovery Environment. In Recovery Environment, Windows may not be mounted as `C:`.

Use DiskPart to identify the destination SSD and destination ESP by size, partition type, and disk layout. Assign a temporary drive letter to the verified ESP:

```cmd
diskpart
list disk
select disk <DEST_DISK_NUMBER>
list partition
select partition <DEST_ESP_PARTITION_NUMBER>
assign letter=<TEMP_LETTER>
exit
```

Then run:

```cmd
bcdboot <WINDOWS_VOLUME>:\Windows /s <TEMP_LETTER>: /f UEFI /v
```

Verify that the destination ESP contains:

```text
<ESP_LETTER>:\EFI\Microsoft\Boot\bootmgfw.efi
```

When `/s` is specified, BCDBoot writes boot files to the specified system partition; depending on the boot scenario, firmware NVRAM entry creation may need to be handled separately. Verify the actual firmware entry rather than assuming it was created.

Never publish BCD store GUIDs, Windows product keys, BitLocker recovery keys, or screenshots containing them.

## 4. Fedora NVRAM entry

Use `efibootmgr` only after verifying the destination ESP and loader path. Example:

```bash
sudo efibootmgr --create \
  --disk /dev/<DEST_DISK> \
  --part <DEST_ESP_PARTITION_NUMBER> \
  --label 'Fedora (Destination)' \
  --loader '\EFI\fedora\shimx64.efi'
```

The actual loader path can vary by distribution/version and Secure Boot configuration. Verify that the file exists.

## 5. Windows NVRAM entry

Example, only if the target loader exists:

```bash
sudo efibootmgr --create \
  --disk /dev/<DEST_DISK> \
  --part <DEST_ESP_PARTITION_NUMBER> \
  --label 'Windows Boot Manager (Destination)' \
  --loader '\EFI\Microsoft\Boot\bootmgfw.efi'
```

## 6. Verify boot entries

```bash
sudo efibootmgr -v
```

Match each entry's GPT partition GUID to the actual ESP's PARTUUID and match the loader path to the file on that ESP. Labels such as `Fedora` or `Windows Boot Manager` are not sufficient proof.

To test one entry on the next boot, use the exact verified Boot#### identifier:

```bash
sudo efibootmgr -n <VERIFIED_BOOT_ENTRY_ID>
sudo reboot
```

This sets a one-time boot target. Be sure the chosen identifier is correct.

## 7. Clean stale entries

Remove only entries proven to point to the old source disk. A safe method is to inspect, remove one entry, and inspect again:

```bash
sudo efibootmgr -b <STALE_BOOT_ENTRY_ID> -B
sudo efibootmgr -v
```

Boot numbers are firmware variables and may change after firmware operations. Re-read the listing before every deletion. Retain working destination OS entries, USB boot, and useful firmware fallback options.

## 8. GRUB refresh after source removal

After the old drive is no longer connected, regenerate Fedora's main GRUB configuration:

```bash
sudo grub2-mkconfig -o /boot/grub2/grub.cfg
```

Inspect the results for unexpected old installations. Do not delete a menu entry solely because its label is duplicated; determine what device and loader it refers to.

## 9. Secure Boot and encryption

Changing EFI boot files can trigger Secure Boot verification or Windows BitLocker recovery. Record Secure Boot state and ensure recovery material is available before making changes. Never request a user's recovery key in chat. If encryption recovery unexpectedly appears, stop and follow the owner's recovery procedure.
