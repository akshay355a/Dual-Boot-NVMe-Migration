# Troubleshooting matrix

| Symptom | First checks | Likely direction |
|---|---|---|
| Fedora enters emergency mode | `cat /etc/fstab`, `blkid`, `findmnt` from live media | Old UUID, wrong subvolume name, missing filesystem, or wrong mount point |
| Fedora only boots while source SSD is installed | `findmnt / /boot /boot/efi`, EFI-side GRUB stub, BLS entries | Hidden dependency on source root, `/boot`, or ESP |
| Fedora appears in firmware but fails | Verify the NVRAM entry's PARTUUID and loader file | Entry points to old ESP or loader path is missing |
| GRUB menu lists old Fedora | Check source availability, `os-prober`, generated config | Regenerate after source removal; inspect custom entries |
| Windows does not appear in GRUB | Verify Microsoft EFI file and `efibootmgr -v` | Missing ESP files, NVRAM entry, or OS-prober detection |
| Windows Boot Manager fails | Verify Windows volume, ESP, `bootmgfw.efi`, BCD, BitLocker state | Run BCDBoot from the correct Windows installation/Recovery Environment |
| Duplicate UEFI entries | Compare partition GUID and loader path | Remove only verified duplicates/stale entries |
| NVMe format reports success but partitions still show | Inspect GPT with `sgdisk --print`; determine whether nodes are stale | Refresh partition map or reboot if safe; don't reformat blindly |
| `nvme format` not supported | Inspect OACS and vendor docs | Use only a controller-supported, vendor-approved sanitization method |
| Secure Boot violation | Verify signed shim/GRUB chain and firmware state | Repair using distribution-supported signed packages |
| BitLocker recovery appears | Do not expose the recovery key | Use the owner's offline recovery procedure; stop boot changes until recovered |

## Diagnostic rules

- One hypothesis at a time. Ask for the smallest sanitized output that can confirm or reject it.
- Distinguish a firmware boot entry from the EFI file it references and from the filesystem containing it.
- Distinguish a filesystem UUID from a GPT PARTUUID and a GPT disk GUID.
- Distinguish a stale Linux kernel partition node from a real current GPT entry.
- Distinguish successful OS startup from proof that all required partitions are on the destination.
