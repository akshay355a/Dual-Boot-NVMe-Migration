# Fedora and Btrfs migration reference

This reference assumes a Fedora installation with Btrfs root/home subvolumes and a separate `/boot`. Confirm the actual source layout first. Other Fedora layouts require adaptation.

## 1. Inspect subvolumes

```bash
sudo mount -o subvolid=5 <SOURCE_BTRFS_PARTITION> <SOURCE_TOPLEVEL_MOUNT>
sudo btrfs subvolume list <SOURCE_TOPLEVEL_MOUNT>
sudo umount <SOURCE_TOPLEVEL_MOUNT>
```

Typical subvolume names may include `root` and `home`, but do not assume these names. Record the actual `subvol=` values in `/etc/fstab` and confirm them against `btrfs subvolume list`.

## 2. Prepare and mount destination

Create a destination Btrfs filesystem only if one does not already exist and only after verifying the exact destination partition. Creating a filesystem is destructive.

Mount its top-level subvolume (`subvolid=5`) and create the required target subvolumes only when absent. Then mount the source root/home and destination root/home separately.

Example mount concepts (replace all placeholders):

```bash
sudo mount -o subvol=root <SOURCE_BTRFS_PARTITION> <SOURCE_ROOT_MOUNT>
sudo mount -o subvol=home <SOURCE_BTRFS_PARTITION> <SOURCE_HOME_MOUNT>
sudo mount -o subvol=root <DEST_BTRFS_PARTITION> <DEST_ROOT_MOUNT>
sudo mount -o subvol=home <DEST_BTRFS_PARTITION> <DEST_HOME_MOUNT>
```

Mount the separate source and destination `/boot` and ESP filesystems at their correct paths before copying those filesystems. Be careful not to copy into an unmounted mountpoint directory.

## 3. Copy root and home offline

Run from a trusted live/rescue environment with source filesystems not actively changing:

```bash
sudo rsync -aHAXS --numeric-ids --info=progress2 \
  <SOURCE_ROOT_MOUNT>/ <DEST_ROOT_MOUNT>/

sudo rsync -aHAXS --numeric-ids --info=progress2 \
  <SOURCE_HOME_MOUNT>/ <DEST_HOME_MOUNT>/
```

Copy the separate `/boot` filesystem separately after mounting both actual filesystems:

```bash
sudo rsync -aHAX --numeric-ids --info=progress2 \
  <SOURCE_BOOT_MOUNT>/ <DEST_BOOT_MOUNT>/
```

`-a` preserves common metadata; `-H` hard links; `-A` ACLs; `-X` extended attributes; `-S` sparse files; `--numeric-ids` numeric ownership. These options are not a substitute for validating SELinux labels, mount options, subvolume layout, and bootloader state. Do not use `--delete` casually.

## 4. Update fstab

Back up the copied file and edit the destination copy, not the running source system:

```bash
sudo cp <DEST_ROOT_MOUNT>/etc/fstab \
  <DEST_ROOT_MOUNT>/etc/fstab.pre-migration
sudoedit <DEST_ROOT_MOUNT>/etc/fstab
```

Example only:

```fstab
UUID=<DEST_BTRFS_UUID>  /          btrfs  subvol=root,compress=zstd:1  0 0
UUID=<DEST_BOOT_UUID>   /boot      ext4   defaults                    1 2
UUID=<DEST_ESP_UUID>    /boot/efi  vfat   umask=0077,shortname=winnt  0 2
UUID=<DEST_BTRFS_UUID>  /home      btrfs  subvol=home,compress=zstd:1 0 0
```

Keep any required swap, other filesystems, mount options and existing subvolume names. Obtain actual UUIDs using `blkid` or `lsblk -f`.

Validate the destination fstab with the installed `findmnt` version (for example, `findmnt --verify --tab-file <DEST_ROOT_MOUNT>/etc/fstab`).

## 5. Update BLS entries

Inspect:

```bash
grep -RIn 'root=UUID=' <DEST_BOOT_MOUNT>/loader/entries/
```

Update only confirmed root filesystem references. Preserve other kernel parameters and do not perform a blind global UUID replacement.

## 6. Chroot and rebuild

Bind mount `/dev`, `/proc`, `/sys`, and `/run` into the destination root, then chroot. Verify `findmnt / /boot /boot/efi`, `/etc/fstab`, BLS entries, and the Fedora EFI-side GRUB configuration before generating GRUB.

```bash
sudo mount --rbind /dev <DEST_ROOT_MOUNT>/dev
sudo mount --make-rslave <DEST_ROOT_MOUNT>/dev
sudo mount --rbind /proc <DEST_ROOT_MOUNT>/proc
sudo mount --make-rslave <DEST_ROOT_MOUNT>/proc
sudo mount --rbind /sys <DEST_ROOT_MOUNT>/sys
sudo mount --make-rslave <DEST_ROOT_MOUNT>/sys
sudo mount --rbind /run <DEST_ROOT_MOUNT>/run
sudo mount --make-rslave <DEST_ROOT_MOUNT>/run
sudo chroot <DEST_ROOT_MOUNT>
```

Inside the chroot:

```bash
findmnt / /boot /boot/efi
cat /etc/fstab
cat /boot/efi/EFI/fedora/grub.cfg
grub2-mkconfig -o /boot/grub2/grub.cfg
```

The file `/boot/efi/EFI/fedora/grub.cfg` (the EFI-side stub) must locate the destination `/boot` filesystem. A copied stub can still reference the source UUID. Do not assume rebuilding the main GRUB configuration automatically repairs every EFI-side reference.

Use Fedora's supported shim/GRUB package reinstall or repair procedure for the installed Fedora release if EFI files are missing or invalid. Do not treat `grub2-install` as a universal UEFI repair command on Fedora.

## 7. Verification

After booting the destination installation:

```bash
findmnt -no SOURCE,FSTYPE,UUID / /boot /boot/efi
cat /etc/fstab
grep -RIn 'root=UUID=' /boot/loader/entries/
```

Cross-check every mounted filesystem against the destination inventory. A successful login alone does not prove `/boot` and the ESP are on the destination.
