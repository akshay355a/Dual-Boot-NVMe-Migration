# Migration workflow and decision gates

## Goal

Move an existing Linux installation and retain Windows on a destination NVMe SSD. This file describes the sequence; platform-specific details are in the Fedora/Btrfs and UEFI/Windows references.

## Stage 0 — Scope and readiness

Record privately:

- Source and destination physical drives.
- Current partition table and filesystem layout on each.
- Existing Windows partition(s), recovery partition(s), ESP(s), Linux `/boot`, and Linux root/home filesystems.
- Firmware mode (UEFI/GPT expected for this workflow).
- Whether Secure Boot and BitLocker/Device Encryption are enabled.
- Backup location and proof that critical files can be restored.

Stop if the source/destination mapping is ambiguous, destination capacity is inadequate, the only backup is on either SSD, or BitLocker recovery material is unavailable.

## Stage 1 — Inventory

Use read-only commands:

```bash
sudo nvme list
sudo lsblk -e7 -o NAME,SIZE,TYPE,FSTYPE,LABEL,UUID,PARTUUID,MOUNTPOINTS
sudo blkid
findmnt -R /
sudo efibootmgr -v
```

Treat output as sensitive. Assign stable local labels such as SOURCE and DESTINATION in notes. Do not publish serials, UUIDs, PARTUUIDs, GPT GUIDs, full UEFI device paths, hostnames or usernames.

Do not infer identity from `/dev/nvme0n1` ordering. Cross-check at least two independent properties and inspect the partition layout.

## Stage 2 — Destination partitioning

Design the destination partition table before changing it. A typical UEFI layout may contain:

- Existing Windows EFI System Partition or a new destination ESP.
- Windows data and recovery partitions that must be preserved.
- Linux `/boot` partition if the distribution uses a separate one.
- Linux Btrfs or other root filesystem.

The exact layout is machine-specific. Do not copy example partition numbers or sizes. Do not format or recreate Windows partitions merely to match an example.

## Stage 3 — Linux data copy

For an offline Fedora/Btrfs migration, create the destination subvolumes intentionally, mount source and destination subvolumes separately, copy root/home metadata-preservingly, and copy a separate `/boot` only after mounting its actual filesystems. See `fedora-btrfs-migration.md`.

Checkpoint: verify rsync exit status, inspect destination directory structure, check ownership/permissions, and confirm `/boot` and the ESP are mounted where expected. Do not proceed if files copied into an unmounted directory on the root filesystem by mistake.

## Stage 4 — Repair Linux references and EFI chain

Update copied `/etc/fstab`, BLS kernel root references, and EFI-side GRUB configuration to the destination filesystem identifiers. Install/repair the destination Fedora shim/GRUB using the distribution-supported package workflow. Regenerate GRUB from the destination installation. See `fedora-btrfs-migration.md` and `uefi-windows-boot.md`.

Checkpoint: inspect the destination EFI files and ensure the EFI-side GRUB stub locates the destination `/boot`, not the source `/boot`.

## Stage 5 — Windows boot files

Use Windows or Windows Recovery Environment, identify the actual Windows installation volume, and run BCDBoot against the verified destination ESP. See `uefi-windows-boot.md`.

Checkpoint: verify Microsoft EFI boot files exist on the destination ESP and the firmware entry points to that ESP.

## Stage 6 — Independent boot testing (mandatory)

Test each OS separately using the firmware one-time boot menu or a verified NVRAM entry:

- Fedora starts from destination; `findmnt` confirms `/`, `/boot`, and `/boot/efi` use destination filesystems.
- Windows starts from destination and the expected volumes/data are available.

Best proof: temporarily make the source unavailable or physically disconnect it, following hardware service instructions, and repeat both boot tests. Never erase the source before these tests pass.

## Stage 7 — Cleanup

Remove only stale UEFI entries whose partition GUID and loader path prove that they point to the source. Keep a working destination Windows entry, Fedora entry, and useful USB/fallback entries. Regenerate GRUB after the source is erased/disconnected so stale OS-prober results disappear.

Checkpoint: re-run `efibootmgr -v` and inspect generated GRUB entries. Do not delete entries based only on their display label.

## Stage 8 — Source sanitization and removal

Read `nvme-erasure.md`. Inspect controller capabilities, select the correct namespace, obtain explicit target confirmation, and use the vendor/policy-approved sanitization method. Verify and document the outcome without overclaiming. Physically remove only after a clean shutdown and according to service/ESD instructions.

## Stage 9 — Acceptance

With the source physically absent:

- Cold boot Fedora; confirm destination root, `/boot`, and ESP.
- Cold boot Windows; confirm normal startup.
- Confirm no dependency on old UEFI entries or old filesystem UUIDs.
- Keep recovery media and backups until both OSes pass post-removal checks.

## Stop conditions

Stop and re-evaluate if a boot test fails, a mount points to the source, a UUID is unknown, the ESP contents are unclear, a Windows encryption recovery screen appears unexpectedly, the source device path changes, or a destructive target cannot be proven.
