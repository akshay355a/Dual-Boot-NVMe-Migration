# NVMe source-drive erasure and verification

## 1. Choose the sanitization method based on capabilities

Do not assume every NVMe controller supports Sanitize, Format NVM, or Cryptographic Erase. Inspect the actual controller and vendor documentation first.

Read-only inspection examples:

```bash
sudo nvme list
sudo nvme id-ctrl /dev/<SOURCE_CONTROLLER> -H
sudo nvme id-ns /dev/<SOURCE_NAMESPACE> -H
```

Check the reported OACS, SANICAP, FNA and namespace capabilities using the installed `nvme-cli` version and device documentation. Capability bits are not interchangeable:

- **Format NVM** is a namespace format operation. Its Secure Erase Settings (SES) field controls whether user data erase is requested.
- **Sanitize** is a separate controller-level sanitization operation with its own supported actions and status reporting.
- **Cryptographic Erase** is a specific erase mechanism/setting. Do not claim it occurred unless the selected command, controller support and completion status establish it.

If the device does not advertise the needed operation, do not invent support or silently substitute a weaker method. Consult the SSD vendor's sanitization guidance.

## 2. Verify the target before destructive commands

Identify the physical source disk and namespace using multiple attributes, including model, serial (kept private), capacity, namespace path, partition layout, and mountpoints.

Confirm:

- The source is not the destination currently running Fedora/Windows.
- No source partitions are mounted or in active use.
- Fedora and Windows boot independently from the destination.
- Backups have been verified.
- The exact target namespace is known.

The assistant must state the exact target and consequences and obtain an explicit confirmation that names the target. Never proceed with an ambiguous `/dev/nvmeXnY` path.

## 3. Format NVM with User Data Erase

Only when the actual controller advertises Format NVM support and the vendor's documentation supports this operation, the generic command form is:

```bash
sudo nvme format /dev/<SOURCE_NAMESPACE> --ses=1
```

`--ses=1` requests **User Data Erase**. It does not mean that every physical NAND cell has been individually overwritten, nor does a success message prove that forensic recovery is impossible. The NVMe specification allows implementation-specific behavior; the post-erase user-data content is indeterminate.

Do not use this command as a generic example against an unverified disk. Do not run it on the controller node if the tool expects a namespace block device.

## 4. Sanitize support

If SANICAP indicates no supported Sanitize actions, do not attempt to run a Sanitize command and do not describe Format NVM as Sanitize. A controller may support Format NVM while not supporting Sanitize.

If a Sanitize action is supported, follow the SSD manufacturer instructions and verify the operation's completion/status using supported NVMe tooling. Understand the selected action (block erase, overwrite, or crypto erase) before executing it.

## 5. Verification after erase

Use non-destructive inspection:

```bash
sudo nvme list
sudo sgdisk --print /dev/<SOURCE_DISK>
sudo lsblk -f /dev/<SOURCE_DISK>
```

Interpret results carefully:

- Namespace utilization/used values may report zero, but this alone is not a forensic proof.
- A partition table inspection may show no entries if metadata was erased.
- The kernel may retain stale partition nodes until the partition map is refreshed or the system reboots.
- Old filesystem signatures or cached partition nodes do not by themselves prove that the erase failed.
- A successful format command does not prove that every inaccessible NAND remnant is unrecoverable.

If the partition view is stale, and the source is not mounted or in use, a partition-table refresh may be attempted:

```bash
sudo partprobe /dev/<SOURCE_DISK>
```

A controlled reboot also refreshes kernel device state. Do not create a new partition table or filesystem merely to make the disk look empty before resale.

## 6. Resale and privacy

After the erase, keep the SSD unpartitioned/unallocated. Do not publish the SSD serial or controller details. If the data was highly sensitive, subject to regulatory rules, or managed under enterprise policy, use a documented vendor-supported sanitization or physical destruction method rather than relying solely on a desktop utility result.

## 7. Honest reporting template

Good:

> The NVMe Format NVM operation with SES=1 completed successfully. Subsequent inspection reported no GPT partition entries and zero namespace utilization. This is evidence that the requested User Data Erase completed, but it is not an independent forensic certification that all physical NAND remnants are unrecoverable.

Avoid:

> The SSD is 100% impossible to recover by any forensic method.
