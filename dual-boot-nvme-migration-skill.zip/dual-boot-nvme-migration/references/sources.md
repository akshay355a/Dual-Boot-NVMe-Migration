# Primary references

These links are starting points. Check the current manuals for the installed versions and hardware before acting.

- Agent Skills format and Claude usage: https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview
- OpenAI / Codex Skills: https://learn.chatgpt.com/docs/build-skills
- OpenAI API Skills guide: https://developers.openai.com/api/docs/guides/tools-skills
- Microsoft BCDBoot command-line options: https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/bcdboot-command-line-options-techref-di
- NVMe CLI project and documentation: https://github.com/linux-nvme/nvme-cli
- `nvme-format` manual: https://github.com/linux-nvme/nvme-cli/blob/master/Documentation/nvme-format.1
- Fedora GRUB 2 reference: https://fedoraproject.org/wiki/GRUB_2
- Fedora Btrfs reference: https://fedoraproject.org/wiki/Btrfs

## Notes

- The skill is an instruction package, not a signed vendor procedure.
- The runbook examples are not universal commands. Device paths, bootloader package names, firmware behavior, and controller capabilities vary.
- Prefer current Fedora documentation, the installed `man` pages, Microsoft documentation, NVMe specification, and the SSD manufacturer's sanitize guide for the target environment.
