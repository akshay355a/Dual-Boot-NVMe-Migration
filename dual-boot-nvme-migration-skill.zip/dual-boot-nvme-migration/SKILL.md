---
name: dual-boot-nvme-migration
description: Safely plan, migrate, troubleshoot, and validate Fedora/Linux plus Windows dual-boot installations between NVMe SSDs using UEFI/GPT, Btrfs, rsync, EFI boot files, and optional source-drive erasure. Use for NVMe migration, Fedora boot repair, Windows EFI/BCDBoot setup, stale UEFI entries, or pre-resale drive sanitization.
---

# Dual-Boot NVMe Migration

Use this skill as a safety-first technical runbook for moving a Linux + Windows UEFI dual-boot system from a source NVMe SSD to a destination NVMe SSD. The reference case used Fedora, Btrfs, a separate `/boot`, a FAT32 EFI System Partition (ESP), Windows 11, and NVMe Format NVM. Adapt every step to the actual machine.

## Quick context

A successful migration has five independent parts:

1. **Storage layout:** destination GPT partitions exist and have enough capacity.
2. **Linux data:** root and home data are copied with metadata preserved; separate `/boot` is copied separately.
3. **Linux boot chain:** destination `fstab`, BLS kernel options, EFI-side GRUB configuration, shim/GRUB files, and generated GRUB configuration refer to the destination.
4. **Windows boot chain:** Microsoft EFI boot files exist on the destination ESP and the firmware can boot them.
5. **Independence:** Fedora and Windows each boot with the source SSD unavailable. Only then may the source be erased or removed.

Do not treat a successful file copy or a visible GRUB menu as proof of a successful migration.

## Non-negotiable safety rules

- **Never infer disk identity from `/dev/nvme0n1` or `/dev/nvme1n1` alone.** Device numbering can change. Identify each drive using multiple local signals: model, serial, capacity, namespace, partition layout, filesystem UUID/PARTUUID, and mountpoints. Do not publish those identifiers.
- Keep a separate verified backup. A second partition on the same physical SSD is not a backup.
- Before any destructive command, state the exact target device and its identifying properties, explain the effect, and obtain the user's explicit confirmation. Never proceed on ambiguous identity or implied consent.
- Never run `nvme format`, `wipefs`, `sgdisk --zap-all`, `dd`, `parted`, `mkfs`, or partition deletion commands until the target and intended scope are proven.
- Do not erase the source until both operating systems have independently booted from the destination. Prefer testing with the source physically disconnected or otherwise unavailable.
- Do not blindly copy an entire ESP over another ESP. It may overwrite Windows or vendor files. Copy only the required bootloader directory after inspection.
- Never claim forensic unrecoverability from a successful format result alone. Explain the controller's supported sanitize capabilities and the limits of verification.
- Protect BitLocker/Device Encryption recovery keys before changing boot configuration. Never ask the user to paste recovery keys, passwords, product keys, or private keys into chat.
- Keep steps incremental. Ask for one relevant diagnostic output at a time; avoid giant command batches.

## Interaction protocol

1. Establish the goal: full migration, boot repair, source erase, or post-migration cleanup.
2. Identify OSes, boot mode (UEFI vs legacy), filesystem/subvolume layout, source and destination disks, and backup status.
3. Ask for sanitized outputs only. Give the user a redaction instruction before requesting logs.
4. Build an explicit source/destination map. Mark every destructive target.
5. Present a staged plan with a stop/checkpoint after inventory, partitioning, copy, configuration, and boot tests.
6. At each checkpoint, compare observed output against the expected state before proceeding.
7. Do not continue when an output contradicts the map. Re-identify rather than guessing.
8. Before final cleanup, distinguish completed, tested, and not-yet-tested items.

## Workflow

Follow the detailed procedures in the reference files. The high-level order is:

1. Read `references/privacy-and-redaction.md` before handling machine inventory.
2. Read `references/migration-workflow.md` for the stage sequence and stop conditions.
3. For Fedora/Btrfs work, read `references/fedora-btrfs-migration.md`.
4. For ESP, BCDBoot, GRUB and NVRAM work, read `references/uefi-windows-boot.md`.
5. For drive sanitization, read `references/nvme-erasure.md` and require a fresh explicit confirmation.
6. Use `references/troubleshooting.md` only when a symptom matches.

## Minimum information to collect

Request only what is needed for the current stage. Common inventory commands include:

```bash
sudo nvme list
sudo lsblk -e7 -o NAME,SIZE,TYPE,FSTYPE,LABEL,UUID,PARTUUID,MOUNTPOINTS
sudo blkid
findmnt -R /
sudo efibootmgr -v
```

These outputs are sensitive. Ask the user to replace serial numbers, UUIDs, PARTUUIDs, GUIDs, device paths, hostnames, usernames, IP/MAC addresses and other identifiers with stable placeholders before sharing. Do not store or reproduce raw identifying values in generated documentation.

## Destructive-action confirmation format

Before a destructive action, summarize:

- Exact target as currently identified (use a locally verified model/serial in private troubleshooting; use placeholders in shareable documents).
- Exact command and scope (controller vs namespace vs partition).
- What will be destroyed and what is expected to remain.
- Backup and independent-boot checks completed.

Then ask for explicit confirmation naming the target. If the user has not confirmed the exact target, do not run or recommend executing the destructive command.

## Output expectations

Produce a practical checklist or step-by-step procedure. Label commands as **read-only**, **configuration-changing**, or **destructive**. Use placeholders such as `<SOURCE_DISK>`, `<SOURCE_NAMESPACE>`, `<DEST_DISK>`, `<DEST_ESP>`, `<DEST_BOOT_UUID>`, and `<DEST_BTRFS_UUID>` in public examples. Explain how to discover each placeholder locally. State assumptions and version-sensitive details. Never claim a task is complete until the relevant command output or boot test confirms it.

## Boundaries

This skill is a guide, not a substitute for hardware service documentation, backup policy, vendor sanitize instructions, or a validated disaster-recovery plan. Do not promise that a drive is impossible to forensically recover. If the SSD has failed, is encrypted, contains regulated data, or has special enterprise sanitization requirements, stop and recommend a vendor-supported or policy-approved process.
