# Dual-Boot NVMe Migration Agent Skill

A portable, privacy-conscious Agent Skill for planning and guiding Linux + Windows dual-boot migrations between NVMe SSDs.

## What is included

- `SKILL.md` — compact agent instructions and safety gates.
- `references/` — detailed workflow, Fedora/Btrfs copy procedure, Windows/UEFI boot configuration, NVMe erase guidance, troubleshooting, and privacy rules.

The package contains no executable scripts and no real machine identifiers. It uses generic placeholders throughout. This is intentional: the agent must discover the user's actual disk layout rather than assume device numbering.

## Quick context for an agent

The reference workflow moves Fedora (Btrfs root/home plus separate `/boot`) to a destination NVMe SSD while preserving an existing Windows installation. The destination receives a valid EFI System Partition with Fedora shim/GRUB and Microsoft boot files. Linux filesystem references and bootloader configuration are updated. Both Fedora and Windows must be tested independently from the destination before the source SSD is erased or removed. A source-drive erase must use a capability-aware procedure, explicit target confirmation, and honest limitations.

## Install

### Claude Code

Copy this directory to:

```text
~/.claude/skills/dual-boot-nvme-migration/
```

For project-only use, place it under:

```text
<project>/.claude/skills/dual-boot-nvme-migration/
```

Then invoke it by asking Claude to use the `dual-boot-nvme-migration` skill, or let Claude Code discover it from the skill description.

### Codex / OpenAI Agent Skills-compatible environments

Copy this directory to the personal skills directory:

```text
~/.agents/skills/dual-boot-nvme-migration/
```

For a repository-scoped skill, use:

```text
<repository>/.agents/skills/dual-boot-nvme-migration/
```

In ChatGPT desktop or another host with a Skills UI, use its skill import flow if available. Product-specific availability and installation steps can change; consult the host documentation.

### Claude.ai

Upload the ZIP archive through Claude's custom Skills interface, when available for the account/workspace. The archive contains one skill directory with `SKILL.md` and its references.

### Other GPTs or agents

The package follows the open Agent Skills folder convention (`SKILL.md` with YAML `name` and `description`, plus optional reference files). A platform must support Agent Skills or filesystem-based skill loading to install it as a native skill. For a chat interface without skill import, attach `SKILL.md` and the relevant reference file(s), or paste the Quick Context section above as background. This is not the same as installing a skill into every custom GPT product.

## Safe use

1. Review the package before installing; skills are instructions and should be treated as trusted code/configuration.
2. Keep real identifiers local. Replace all values with placeholders before sharing logs or screenshots.
3. Never execute destructive commands from the skill without verifying the target on the live machine and obtaining explicit confirmation.
4. Do not use the example workflow blindly on different partition layouts, distributions, firmware modes, or SSD controllers.

## Version and sources

Package revision: 1.0.0 (2026-11-01)

The reference material is based on an anonymized Fedora + Windows migration case and current public documentation linked in `references/sources.md`. Validate commands against the installed distribution and tool versions before production use.
